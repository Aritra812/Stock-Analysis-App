
# -*- coding: utf-8 -*-

__all__ = ['malaysia',
           ]

from . import *
