
# -*- coding: utf-8 -*-

__all__ = ['beautiful',
           ]

from . import *
