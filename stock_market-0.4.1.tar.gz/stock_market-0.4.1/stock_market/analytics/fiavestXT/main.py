
# -*- coding: utf-8 -*-


def main():
    return 0


if __name__ == '__main__':
    pass
